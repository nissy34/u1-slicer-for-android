#ifndef __SLIC3R_VERSION_H
#define __SLIC3R_VERSION_H
#define SLIC3R_APP_NAME "SnapmakerOrcaSlicer"
#define SLIC3R_APP_KEY "SnapmakerOrcaSlicer"
#define SLIC3R_VERSION "2.2.4"
#define Snapmaker_VERSION "2.2.4"
#define SLIC3R_BUILD_ID "android-arm64"
#define SLIC3R_BUILD_TIME "20260306"
#define BBL_RELEASE_TO_PUBLIC 0
#define BBL_INTERNAL_TESTING 0
#define ORCA_CHECK_GCODE_PLACEHOLDERS 0
#endif /* __SLIC3R_VERSION_H */
